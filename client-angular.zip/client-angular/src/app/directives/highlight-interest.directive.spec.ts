

import { HighlightInterestDirective } from './highlight-interest.directive';

describe('HighlightInterestDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlightInterestDirective();
    expect(directive).toBeTruthy();
  });
});


